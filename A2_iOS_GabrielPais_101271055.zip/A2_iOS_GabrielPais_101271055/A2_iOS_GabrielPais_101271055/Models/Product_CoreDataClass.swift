import Foundation
import CoreData

@objc(Product)
public class Product: NSManagedObject {

}
